﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FeedbackApp.BLL.VMs.Product
{
    public class CreateProduct
    {
        public string Name { get; set; }
        public string Category { get; set; }
    }
}
